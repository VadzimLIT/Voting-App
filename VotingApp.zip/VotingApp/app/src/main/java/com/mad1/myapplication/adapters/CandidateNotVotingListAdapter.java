package com.mad1.myapplication.adapters;

public class CandidateNotVotingListAdapter {
}
