package com.mad1.myapplication.utility;

public class NumberOfCandidates {
    public static int number_of_candidates = 0;
}
