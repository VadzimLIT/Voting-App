package com.mad1.myapplication;

import android.util.Base64;

import com.mad1.myapplication.security.Cryptography;
import com.mad1.myapplication.validation_utility.ValidationUtility;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */

@RunWith(JUnit4.class)
public class DatabaseUnitTests {

}
